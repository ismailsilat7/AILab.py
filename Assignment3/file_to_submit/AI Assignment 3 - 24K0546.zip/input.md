**AI Assignment 3 - 24K0546**

**Student Information**

Name: Ismail Silat

Roll No: 24K-0546

Section: BCS-4H

Submission Date: 27 April, 2026

**1. Competition Overview**

\- Competition Name: Predicting Irrigation Need

\- Problem Type: Multiclass Classification

\- Evaluation Metric: Balanced Accuracy Score

\- Brief understanding of the dataset:

My target is irrigation_need with 3 classes **(Low, Medium, High)** so a
multiclass classification would be needed with balanced accuracy (as per
kaggle requirements), the dataset consists of 21 columns with the last
one - target (irrigation_need), & rest as

Labels:
id,Soil_Type,Soil_pH,Soil_Moisture,Organic_Carbon,Electrical_Conductivity,Temperature_C,Humidity,**Rainfall_mm,**Sunlight_Hours,Wind_Speed_kmh,Crop_Type,Crop_Growth_Stage,Season,Irrigation_Type,Water_Source,Field_Area_hectare,Mulching_Used,**Previous_Irrigation_mm,**Region,

with Soil_type *(Clay, Loamy, Sandy, Silt),* Crop_Type *(Cotton, Maze,
Potato, Rice, Sugarcane, Wheat)*, Crop_Growth_Stage *(Flowering,
Harvest, Sowing, Vegetative)*, Season (*Kharif, Rabi, Zaid)*,
Irrigation_Type *(Canal, Drip, Rainfed, Sprinkler)*, Water_Source
*(Groundwater, Rainwater, Reservoir, River)*, Mulching_Used *(Yes, No)*,
and Region *(Central, North, East, West, South)* requiring encoding (as
these are non-numerical)

**2. Data Preprocessing**

\- Missing values handling: No missing values were found in the dataset,
so no missing value handling was required.

\- Encoding technique: The following required encoding as they had
categorical data: Soil_Type, Crop_Type, Crop_Growth_Stage, Season,
Irrigation_Type, Water_Source, Mulching_Used, Region. **Label Encoding**
was used by assigning a *unique integer to each category.*

\- Feature scaling: StandardScaler was applied to normalize all features
to have mean of 0 & standard deviation of 1, this was necessary for
distance based model (kNN).

\- Train-validation split: data was divided into training & validation
(with_held) set. 80% was set as training data & the other 20% for
validation, making the **test_size 0.2**, with random_state=42 for
reproducibility

**3. Models Attempted**

\- KNN

\- Naive Bayes

> \- Logistic Regression

\- Decision Tree

\- RandomForest (Advanced Model)

**4. Cross Validation Strategy**

\- K-Fold details: k=5, All models were evaluated using 5-Fold cross
validation on the data set. The data was divided into 5 equal chunks &
the model was trained 5 times each time using a different chunk as the
validation set. The 5 scores were averaged for the final test score.

\- LOOCV observations: requires training data set for N times where N is
the number of rows, the data set as 629999 rows which is computationally
infeasible.

\- Best validation accuracy: Decision Tree (max_depth=10) achieved the
best CV score of 0.9608 ± 0.0009

**5. Failed Attempts and Insights**

**- Model used - kNN**

**- Accuracy obtained**

k=5: 0.4018

k=11: 0.3923

**- Confusion matrix screenshot - What went wrong?**

> ![](./image8.png){width="5.305555555555555in"
> height="1.1867694663167103in"}
>
> ![](./image7.png){width="5.305555555555555in"
> height="1.0115266841644794in"}

KNN performed poorly because the dataset is high-dimensional and
contains both numerical and encoded categorical features. Distance-based
methods struggle in such spaces, especially without feature scaling.

**- What was improved?**

Increasing the value of k slightly reduced noise but did not
significantly improve performance. The model still remained unstable and
biased toward majority classes.

> **- Model used - Naive Bayes**
>
> **- Accuracy obtained** :0.5615
>
> **- Confusion matrix screenshot - What went wrong?**
>
> ![](./image9.png){width="5.3365277777777775in"
> height="1.0694444444444444in"}
>
> Naive Bayes assumes that all features are independent, which is not
> true in this dataset (e.g., rainfall, humidity, and soil moisture are
> related). This caused incorrect probability estimations.
>
> **- What was improved?**
>
> Despite its simplicity, Naive Bayes performed better than KNN, but
> still failed to capture complex relationships between features.
>
> **- Model used - Logistic Regression**
>
> **- Accuracy obtained**: 0.5381
>
> **- Confusion matrix screenshot - What went wrong?**
>
> ![](./image6.png){width="5.013888888888889in"
> height="1.9583902012248469in"}
>
> Logistic Regression struggled due to non-linear relationships between
> features and class labels. Additionally, convergence warnings
> indicated that the model did not fully optimize due to lack of feature
> scaling.
>
> **- What was improved?**
>
> Increasing maximum iterations improved stability slightly, but
> performance remained limited.
>
> **- Model used - Decision Tree**
>
> **- Accuracy obtained**
>
> Default: 0.9447
>
> Depth = 10: 0.9593 (better result)
>
> Depth = 7 (tuned): **0.9619** **( best result)**
>
> **- Confusion matrix screenshot - What went wrong?**
>
> ![](./image4.png){width="5.125in" height="0.9461537620297463in"}
>
> ![](./image5.png){width="5.083333333333333in"
> height="0.9506999125109361in"}
>
> ![](./image1.png){width="5.192708880139983in"
> height="0.9608934820647419in"}
>
> Default decision trees tend to overfit when depth is unrestricted.
>
> **- What was improved?**
>
> Hyperparameter tuning via RandomizedSearchCV on additional parameters
> (min_samples_split, min_samples_leaf, criterion, max_features,
> min_impurity_decrease) with depth fixed at 7 yielded the best overall
> result.
>
> **- Model used - Random Forest**
>
> **- Accuracy obtained**: 0.9562
>
> **- Confusion matrix screenshot - What went wrong?**
>
> ![](./image3.png){width="5.434027777777778in"
> height="0.9673928258967629in"}
>
> Although Random Forest performed strongly, it did not outperform the
> tuned Decision Tree in this case.
>
> **- What was improved?**
>
> Ensemble learning improved stability compared to a single tree,
> reducing variance in predictions. **Further hyperparameter tuning
> (e.g. n_estimators, max_depth, max_features) was not pursued due to
> the high computational cost of training multiple trees on 630,000
> rows**, which made exhaustive search impractical within time
> constraints.

**6. Final Model Selection**

Best model: **Decision Tree Classifier (max_depth = 10)**

**- Hyperparameters**

> max_depth = 7
>
> min_samples_split = 5
>
> min_samples_leaf = 8
>
> min_impurity_decrease = 0.0
>
> max_features = None
>
> criterion = entropy
>
> random_state = 42

**- Why selected?**

This model was selected because it achieved the **highest balanced
accuracy score (0.9619)** among all tested models. It also showed;
**strong performance** across all three classes (Low, Medium, High),
reduced overfitting compared to an unrestricted decision tree, and
**better generalization** than Logistic Regression, Naive Bayes, and
KNN. Compared to Random Forest, it performed slightly better while being
simpler and easier to interpret with **lower computational costs**.
Hyperparameters were found using RandomizedSearchCV over 20 random
combinations, searching on a 30% stratified sample of training data for
efficiency.

**7. Leaderboard Performance - Kaggle score**

\- Rank **[2738]{.mark}**

\- Screenshot attached

![](./image2.png){width="7.486466535433071in"
height="3.513888888888889in"}

**Submission with name: Ismail Silat**

**8. Conclusion and Learnings**

\- Key insights

This project demonstrated that tree-based models are highly effective
for multiclass classification problems involving mixed numerical and
categorical features. Decision Trees and Random Forests outperformed
linear and distance-based models.

\- Challenges faced

1.  Encoding multiple categorical variables correctly

2.  Ensuring fair comparison across models

3.  Handling convergence issues in Logistic Regression

4.  Interpreting confusion matrices for multiclass outputs

\- Future improvements

1.  Applying feature scaling to improve Logistic Regression performance

2.  Using advanced ensemble models

3.  Performing hyperparameter tuning

4.  Exploring feature selection to reduce noise and improve
    > generalization
